let dados = [
  {
    titulo : "astronomia",
    descrição : "Astronomia é uma ciência que estuda a composição e formação dos corpos celestese os fenômenos que acontecem noUniverso. É considerada a mais antiga das ciências, tendo se originado,há milhares de anos, com base na observação do comportamento dos astros e estrelas nos céus.",
    link : "https://pt.wikipedia.org/wiki/Astronomia",
  },
  {
    titulo : "Cosmologia",
    descrição : "Atualmente, a cosmologia é uma vertente de estudos da Astronomia  que lida diretamente com a origem do Universo por meio do uso de aparelhos tecnológicos e de cálculos físicos avançados.",
    link : "https://pt.wikipedia.org/wiki/Cosmologia",
  },
  {
    titulo : "estrelas",
    descrição : "Estrelas são corpos formados por uma estrutura gasosa que leva a reações de fusão nuclear, responsáveis pela emissão de energia. O Sol é a estrela mais próxima da Terra. As estrelas são formadas por gases e poeira que sofreram colapso gravitacional no interior das nebulosas.",
    link : "https://pt.wikipedia.org/wiki/Estrela"
  },
]
 



