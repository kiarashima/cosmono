 function pesquisar() {
   //obtém a seção html onde os resultados serão exibidos

    let section = document.getElementById("resultados-pesquisa")

    let campoPesquisa = document.getElementById("campo-pesquisa").value
    console.log(campoPesquisa);

    //inicializa uma string vazia pra armazenar os resultados 
let resultados ="";
//ltera sobre cada dado da lista  de dados
for(let dado of dados) {
   // cria um elemento html para cada resultado 
resultados +=  
'<div class= "item-resultados>'
<h2>
        <a href= "#" target="_blank">${dado.titulo}</a>
        
'</h2>'
 
    'titulo : "Cosmologia'
   'descrição  "Atualmente, a cosmologia é uma vertente de estudos da Astronomia'
   'que lida diretamente com a origem do Universo por meio do uso de aparelhos tecnológicos e de cálculos físicos avançados.'
   'link : "https://pt.wikipedia.org/wiki/Cosmologia'
    
   'titulo : "astronomia'
   ' descrição : "Astronomia é uma ciência que estuda a composição e formação dos corpos celestese os fenômenos que acontecem noUniverso'
    'É considerada a mais antiga das ciências, tendo se originado,há milhares de anos, com base na observação do comportamento dos astros e'
    'estrelas nos céus.'
   ' link : "https://pt.wikipedia.org/wiki/Astronomia'

    
        
}
       
section.innerHTML = resultados

 
     
 }
 

 